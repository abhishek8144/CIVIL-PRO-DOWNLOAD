CIVIL PRO — Android source project (v2.1)

## Included features
- Offline concrete volume calculator
- Reinforcement bar nominal weight calculator (D² / 162 × length)
- Brickwork volume and approximate brick count
- Plaster area and wet mortar volume
- Floor tile count with configurable wastage
- Area-based construction cost estimate
- Slab, beam, column and footing preliminary concrete / user-entered steel allowance
- Combined building quantity summary

## Upgrade notes
- Version bumped to 2.1 (versionCode 3).
- Input parsing now rejects blank, malformed, NaN and infinite values rather than silently treating them as zero.
- Added range/positive-value validation to the main standalone calculators.
- Construction spreadsheets supplied with the project are preserved in `docs/reference_workbooks/` as reference material; they are not imported into or automatically calculated by the Android app.
- Added a GitHub Actions workflow to build the debug APK on pushes and pull requests.

## Build locally
Open this project root in Android Studio and sync Gradle. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## GitHub build
Push this repository to GitHub. The workflow at `.github/workflows/android.yml` runs `assembleDebug` and uploads the APK as a workflow artifact.

## Engineering disclaimer
This app provides preliminary quantity estimates only. It is not structural design software and does not generate reinforcement design or a bar bending schedule. Confirm dimensions, deductions, mix assumptions, reinforcement and applicable Indian Standards with a qualified engineer before construction. Steel intensity in member/building screens is a user-entered planning allowance, not a design recommendation.
