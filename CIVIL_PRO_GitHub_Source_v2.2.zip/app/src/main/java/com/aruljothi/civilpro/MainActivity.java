package com.aruljothi.civilpro;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.text.DecimalFormat;

public class MainActivity extends Activity {
    private final int RED = Color.rgb(210, 20, 35);
    private final int NAVY = Color.rgb(18, 35, 115);
    private final int DARK = Color.rgb(35, 35, 35);
    private final DecimalFormat df = new DecimalFormat("#,##0.###");
    private LinearLayout root, content;
    private String current = "Home";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(RED);
        getWindow().setNavigationBarColor(Color.BLACK);
        showHome();
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }
    private void setup(String title) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(250,250,250));
        setContentView(root);
        TextView bar = text("CIVIL PRO  |  " + title, 20, Color.WHITE, true);
        bar.setBackgroundColor(RED); bar.setPadding(18,20,12,20);
        root.addView(bar);
        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(16,16,16,24);
        scroll.addView(content); root.addView(scroll);
    }
    private void heading(String s) {
        TextView t = text(s, 17, NAVY, true);
        t.setPadding(2,18,2,8); content.addView(t);
    }
    private void note(String s) {
        TextView t = text(s, 12, Color.DKGRAY, false);
        t.setPadding(4,8,4,8); content.addView(t);
    }
    private void button(String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false);
        b.setTextColor(Color.WHITE); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(RED));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,6,0,6);
        content.addView(b,p); b.setOnClickListener(v -> action.run());
    }
    private EditText input(String hint, String value) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setText(value);
        e.setHint(hint); e.setTextSize(16); e.setInputType(8194);
        content.addView(e); return e;
    }
    private double val(EditText e) {
        String raw = e.getText().toString().trim();
        if (raw.isEmpty()) return Double.NaN;
        try {
            double value = Double.parseDouble(raw);
            return Double.isFinite(value) ? value : Double.NaN;
        } catch (Exception ex) {
            return Double.NaN;
        }
    }
    private boolean validPositive(double... values) {
        for (double value : values) {
            if (!Double.isFinite(value) || value <= 0) return false;
        }
        return true;
    }
    private boolean validNonNegative(double... values) {
        for (double value : values) {
            if (!Double.isFinite(value) || value < 0) return false;
        }
        return true;
    }
    private void result(String s) {
        TextView t = text(s,16,NAVY,true);
        t.setBackgroundColor(Color.rgb(239,242,250)); t.setPadding(14,16,14,16);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,12,0,12);
        content.addView(t,p);
    }
    private void showHome() {
        setup("Engineering Tools");
        ImageView brand = new ImageView(this);
        brand.setImageResource(com.aruljothi.civilpro.R.drawable.arulojothi_logo);
        brand.setAdjustViewBounds(true);
        brand.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams brandParams = new LinearLayout.LayoutParams(-1, 170);
        brandParams.setMargins(0, 0, 0, 8);
        content.addView(brand, brandParams);
        TextView welcome = text("Smart Construction. Accurate Calculation.",16,DARK,true);
        welcome.setPadding(0,8,0,16); content.addView(welcome);
        note("ARULJOTHI branding • English • Offline calculations");
        heading("CONSTRUCTION QUANTITY");
        button("Concrete Volume Calculator", () -> concrete());
        button("Steel Weight Calculator", () -> steel());
        button("Brickwork Calculator", () -> brick());
        button("Plaster Area & Material Calculator", () -> plaster());
        button("Tile Quantity Calculator", () -> tiles());
        heading("INDIVIDUAL MEMBER CALCULATORS");
        button("Slab: Concrete + Steel Estimate", () -> member("Slab"));
        button("Beam: Concrete + Steel Estimate", () -> member("Beam"));
        button("Column: Concrete + Steel Estimate", () -> member("Column"));
        button("Footing: Concrete + Steel Estimate", () -> member("Footing"));
        heading("COMPLETE BUILDING ESTIMATION");
        button("Building Quantity Calculator", () -> building());
        heading("ESTIMATION");
        button("Construction Cost Estimator", () -> cost());
        heading("EXCEL-MATCHED WORKSHEETS (15)");
        String[] excelNames = {
            "Concrete Quantity - Slab", "Concrete Quantity - Beam", "Concrete Quantity - Column",
            "Concrete Quantity - Footing", "Steel Quantity - Slab", "Steel Quantity - Beam",
            "Steel Quantity - Column", "Steel Quantity - Footing", "Brickwork Quantity",
            "Material Quantity", "Plastering Quantity", "Painting Quantity",
            "Plaster + Painting Total", "Tile Quantity", "Total Building Cost"
        };
        for (int i=0; i<excelNames.length; i++) {
            final int sheetId=i;
            button(excelNames[i], () -> excelSheet(sheetId));
        }
        heading("ABOUT");
        note("CIVIL PRO version 2.0\nAll results are preliminary estimates. Verify dimensions, structural design, reinforcement detailing and applicable Indian Standards with a qualified engineer before construction.");
    }
    private void backButton() { button("← Home", () -> showHome()); }




    // Fifteen offline calculators mapped to the supplied Excel workbook equations.
    // Each screen exposes the variables used by its corresponding workbook formula.
    private void excelSheet(int id) {
        final String[] names={"Concrete Quantity - Slab","Concrete Quantity - Beam","Concrete Quantity - Column",
            "Concrete Quantity - Footing","Steel Quantity - Slab","Steel Quantity - Beam","Steel Quantity - Column",
            "Steel Quantity - Footing","Brickwork Quantity","Material Quantity","Plastering Quantity",
            "Painting Quantity","Plaster + Painting Total","Tile Quantity","Total Building Cost"};
        setup(names[id]); backButton();
        heading("Enter dimensions and rates in the units shown");
        final EditText[] f = new EditText[8];
        String[] labels = new String[8], defaults = new String[8];
        switch(id) {
            case 0: labels=new String[]{"Slab length (ft)","Slab breadth (ft)","Thickness (ft)","Number of slabs","Concrete mix (M15 / M20 / M25)"}; defaults=new String[]{"30","40","0.5","1","M20"}; break;
            case 1: labels=new String[]{"Beam breadth (ft)","Beam depth (ft)","Beam length (ft)","Number of beams","Concrete mix (M15 / M20 / M25)"}; defaults=new String[]{"0.75","1.25","25","1","M20"}; break;
            case 2: labels=new String[]{"Column width (ft)","Column depth (ft)","Column height (ft)","Number of columns","Concrete mix (M15 / M20 / M25)"}; defaults=new String[]{"1","1","25","1","M20"}; break;
            case 3: labels=new String[]{"Footing length (ft)","Footing width (ft)","Footing height (ft)","Number of footings","Concrete mix (M15 / M20 / M25)"}; defaults=new String[]{"4","4","2","1","M20"}; break;
            case 4: labels=new String[]{"Slab breadth (ft)","Slab length (ft)","Main bar dia (mm)","Distribution bar dia (mm)","Spacing (ft)","Steel rate (₹/kg)"}; defaults=new String[]{"10","16","10","8","0.5","70"}; break;
            case 5: case 6: labels=new String[]{"Bar diameter (mm)","Bar length / column height (ft)","Number of bars"}; defaults=new String[]{"16","25","6"}; break;
            case 7: labels=new String[]{"Bar diameter (mm)","Footing length (ft)","Footing width (ft)","Bar spacing (ft)","Steel rate (₹/kg)"}; defaults=new String[]{"10","4","4","0.5","70"}; break;
            case 8: labels=new String[]{"Wall length (ft)","Wall thickness (ft)","Wall height (ft)"}; defaults=new String[]{"10","0.75","10"}; break;
            case 9: case 14: labels=new String[]{"Building floor area (sq.ft)","Roof height (ft)"}; defaults=new String[]{"1000","10"}; break;
            case 10: case 11: case 12: labels=new String[]{"Total outside perimeter / wall length (ft)","Building / wall height (ft)"}; defaults=new String[]{"100","10"}; break;
            case 13: labels=new String[]{"Building area (sq.ft)"}; defaults=new String[]{"1100"}; break;
        }
        int n=labels.length;
        for(int i=0;i<n;i++) {
            f[i]=input(labels[i],defaults[i]);
        }
        final EditText cementRate, sandRate, stoneRate;
        if(id<=3) {
            cementRate=input("Cement price (₹/bag)","300");
            sandRate=input("Sand price (₹/unit)","7000");
            stoneRate=input("Stone price (₹/unit)","7000");
        } else { cementRate=null; sandRate=null; stoneRate=null; }
        button("Calculate", () -> {
            double[] v=new double[n];
            for(int i=0;i<n;i++){v[i]=val(f[i]); if(!Double.isFinite(v[i]) || v[i]<=0){result("Please enter a positive number in every field.");return;}}
            String out="";
            if(id<=3) {
                double vol=v[0]*v[1]*v[2]*v[3]/35.319;
                String mix=f[4].getText().toString().trim().toUpperCase();
                double cementDiv=mix.equals("M15")?7:(mix.equals("M25")?4:5.5);
                double sandPart=mix.equals("M15")?2:(mix.equals("M25")?1:1.5);
                double stonePart=mix.equals("M15")?4:2;
                double totalParts=cementDiv;
                double cementKg=vol/totalParts*1.54*1440;
                double sandCft=vol/totalParts*sandPart*1.54*35.319;
                double stoneCft=vol/totalParts*stonePart*1.54*35.319;
                double cRate=val(cementRate), sRate=val(sandRate), stRate=val(stoneRate);
                out="Concrete volume: "+df.format(vol)+" m³\nCement: "+df.format(cementKg/50)+" bags\nSand: "+df.format(sandCft/100)+" units\nStone: "+df.format(stoneCft/100)+" units\nEstimated material cost: ₹"+df.format((cementKg/50)*cRate+(sandCft/100)*sRate+(stoneCft/100)*stRate);
                if(!(cRate>=0&&sRate>=0&&stRate>=0)){result("Enter valid non-negative material rates.");return;}
            } else if(id==4) {
                double wt=((v[1]/v[4])*(v[2]*v[2]/162)*(v[0]/3.281))+((v[0]/v[4])*(v[3]*v[3]/162)*(v[1]/3.281));
                out="Total steel weight: "+df.format(wt)+" kg\nMain rods (12 m): "+df.format((v[1]/v[4])*(v[0]/3.281)/12)+"\nDistribution rods (12 m): "+df.format((v[0]/v[4])*(v[1]/3.281)/12)+"\nEstimated steel cost: ₹"+df.format(wt*v[5]);
            } else if(id==5 || id==6) {
                double wt=(v[0]*v[0]/162)*(v[1]/3.281)*v[2];
                out="Steel weight: "+df.format(wt)+" kg\n12 m rods to buy (workbook formula): "+df.format(v[1]*v[2]/(3.281*12))+"\nSteel amount: ₹"+df.format(wt*70);
            } else if(id==7) {
                double wt=((v[0]*v[0])/(162*3.281))*((v[1]/v[3])+(v[2]/v[3]))*((v[1]+v[2])/2);
                out="Footing steel weight: "+df.format(wt)+" kg\n12 m rods (workbook expression): "+df.format(((v[1]/v[3])+(v[2]/v[3]))*((v[1]+v[2])/2)/(12*3.281))+"\nSteel amount: ₹"+df.format(wt*v[4]);
            } else if(id==8) {
                double vol=v[0]*v[1]*v[2];
                out="Wall volume: "+df.format(vol)+" ft³\n9-inch bricks: "+df.format(vol*8.91)+"\n4-inch hollow blocks: "+df.format(vol*2.23)+"\n6-inch hollow blocks: "+df.format(vol*1.623)+"\n8-inch hollow blocks: "+df.format(vol*1.255)+"\nRenacon blocks: "+df.format(vol*1.561)+"\nCement: "+df.format(vol*0.07)+" bags\nSand: "+df.format(vol*0.35)+" CFT";
            } else if(id==9 || id==14) {
                double area=v[0]*(v[1]/10.0);
                double cement=area*.67, msand=area*2.1/100, steel=area*5, psand=area/100, bricks=area*15;
                double ca34=area*1.5/100, ca12=area*6/1000, plaster=area*6.5, wood=area*.45, paint=plaster, tank=area*2.5;
                if(id==9) out="Scaled building area: "+df.format(area)+" sq.ft\nCement: "+df.format(cement)+" bags\nM-sand: "+df.format(msand)+" units\nSteel: "+df.format(steel)+" kg\nP-sand: "+df.format(psand)+" units\nBricks: "+df.format(bricks)+"\n3/4 in aggregate: "+df.format(ca34)+" units\n1½ in aggregate: "+df.format(ca12)+" units\nPlaster/painting area: "+df.format(plaster)+" sq.ft\nWood: "+df.format(wood)+" sq.ft\nWater tank: "+df.format(tank)+" litres\nWorkbook cost allowance: ₹"+df.format(area*2500);
                else out="Scaled building area: "+df.format(area)+" sq.ft\nEstimated workbook total: ₹"+df.format(area*2597)+"\nMaterial quantities: cement "+df.format(cement)+" bags; M-sand "+df.format(msand)+" units; steel "+df.format(steel)+" kg; P-sand "+df.format(psand)+" units; bricks "+df.format(bricks)+"; 3/4 in aggregate "+df.format(ca34)+" units; 1½ in aggregate "+df.format(ca12)+" units; plaster "+df.format(plaster)+" sq.ft; wood "+df.format(wood)+" sq.ft; painting "+df.format(paint)+" sq.ft; tank "+df.format(area*10)+" litres.";
            } else if(id==10) {
                double area=v[0]*v[1];
                out="Plaster area: "+df.format(area)+" sq.ft\nSand: "+df.format(area*4.3)+" CFT\nCement: "+df.format(area*.01673)+" bags\nLabour: ₹"+df.format(area*30)+"\nTotal plastering cost: ₹"+df.format(area*70);
            } else if(id==11) {
                double area=v[0]*v[1];
                out="Painting area: "+df.format(area)+" sq.ft\nPrimer: "+df.format(area/100*3.5)+" L\nPutty (2 coats): "+df.format(area/14*3.5)+" kg\nPaint: "+df.format(area/80*3.5)+" L\nWood putty: "+df.format(area*.446*.51/10.66)+" kg\nWood primer: "+df.format(area*.446*.51/40)+" L\nEnamel: "+df.format(area*.446*.51/32)+" L\nLabour: ₹"+df.format(area*32)+"\nTotal painting cost: ₹"+df.format(area*85);
            } else if(id==12) {
                double area=v[0]*v[1];
                out="Combined area: "+df.format(area)+" sq.ft\nPlaster sand: "+df.format(area*4.3)+" CFT; cement: "+df.format(area*.01673)+" bags\nPlaster cost: ₹"+df.format(area*70)+"\nPainting cost: ₹"+df.format(area*85)+"\nCombined total: ₹"+df.format(area*155);
            } else if(id==13) {
                double area=v[0], floor=area*1.1, wall=area*.75, elevation=area/2.5, skirt=area/2;
                out="Floor tile: "+df.format(floor)+" sq.ft\nWall tile: "+df.format(wall)+" sq.ft\nElevation tile: "+df.format(elevation)+" sq.ft\nSkirting: "+df.format(skirt)+" RFT\nLabour cost: ₹"+df.format((floor+wall+elevation+skirt)*30)+"\nMaterial cost: ₹"+df.format((floor+wall+elevation+skirt)*110)+"\nTotal tile cost: ₹"+df.format((floor+wall+elevation+skirt)*140);
            }
            result(names[id]+"\n"+out+"\n\nBased on the supplied workbook formulas. Check units, quantities and current rates before use.");
        });
        note("Offline workbook-based estimate. The source spreadsheets contain approximate factors, fixed example rates and some inconsistent formulas (including a footing rod-count expression). Results are estimates, not structural design or approved BOQ. Verify all assumptions with a qualified engineer.");
    }

    // Preliminary quantity tools only. Steel intensity is user-entered, not structural design.
    private void member(String type) {
        setup(type + " Estimate"); backButton();
        heading(type + " dimensions");
        EditText count = input(type.equals("Slab") ? "Number of slabs" : "Number of members", "1");
        EditText length = input("Length (m)", type.equals("Slab") ? "5" : "4");
        EditText width = input(type.equals("Slab") ? "Width (m)" : "Width (m)", type.equals("Slab") ? "4" : "0.23");
        EditText depth = input(type.equals("Slab") ? "Thickness (m)" : "Depth / height (m)", type.equals("Slab") ? "0.15" : "0.45");
        EditText steelRate = input("Planning steel intensity (kg/m³) - enter engineer-approved value", "0");
        button("Calculate quantities", () -> {
            double n=val(count), l=val(length), w=val(width), d=val(depth), r=val(steelRate);
            if(!validPositive(n,l,w,d) || !validNonNegative(r)) {
                result("Enter positive dimensions and count. Steel intensity cannot be negative."); return;
            }
            double volume=n*l*w*d;
            result(type + " concrete volume: " + df.format(volume) + " m³\n"
                + "Planning steel allowance: " + df.format(volume*r) + " kg\n"
                + "Steel intensity used: " + df.format(r) + " kg/m³");
        });
        note("Steel is only a user-entered planning allowance. This tool does NOT design reinforcement, determine bar sizes/spacing, check strength, or generate a BBS. Obtain reinforcement from approved structural drawings.");
    }

    private void building() {
        setup("Building Quantity Estimate"); backButton();
        heading("A. Slab quantities");
        EditText slabN=input("Number of slabs","1");
        EditText slabL=input("Slab length (m)","10");
        EditText slabW=input("Slab width (m)","8");
        EditText slabT=input("Slab thickness (m)","0.15");
        EditText slabR=input("Slab planning steel intensity (kg/m³)","0");
        heading("B. Beam quantities");
        EditText beamN=input("Total beam count","10");
        EditText beamL=input("Average beam length (m)","4");
        EditText beamW=input("Beam width (m)","0.23");
        EditText beamD=input("Beam depth (m)","0.45");
        EditText beamR=input("Beam planning steel intensity (kg/m³)","0");
        heading("C. Column quantities");
        EditText colN=input("Column count","12");
        EditText colW=input("Column width (m)","0.23");
        EditText colD=input("Column depth (m)","0.30");
        EditText colH=input("Column height per floor (m)","3");
        EditText colR=input("Column planning steel intensity (kg/m³)","0");
        heading("D. Footing quantities");
        EditText footN=input("Footing count","12");
        EditText footL=input("Footing length (m)","1.5");
        EditText footW=input("Footing width (m)","1.5");
        EditText footD=input("Footing thickness (m)","0.45");
        EditText footR=input("Footing planning steel intensity (kg/m³)","0");
        button("Calculate building quantities", () -> {
            double[] v={val(slabN),val(slabL),val(slabW),val(slabT),val(slabR),
                val(beamN),val(beamL),val(beamW),val(beamD),val(beamR),
                val(colN),val(colW),val(colD),val(colH),val(colR),
                val(footN),val(footL),val(footW),val(footD),val(footR)};
            for(double x:v) { if(!Double.isFinite(x) || x<0) { result("Enter valid numeric values; values cannot be negative."); return; } }
            for(int i=0;i<v.length;i++) {
                if((i%5)!=4 && v[i]<=0) { result("Counts and dimensions must be greater than zero."); return; }
            }
            double sv=v[0]*v[1]*v[2]*v[3], bv=v[5]*v[6]*v[7]*v[8];
            double cv=v[10]*v[11]*v[12]*v[13], fv=v[15]*v[16]*v[17]*v[18];
            double total=sv+bv+cv+fv;
            double steel=sv*v[4]+bv*v[9]+cv*v[14]+fv*v[19];
            result("PRELIMINARY BUILDING SUMMARY\n"
                +"Slab concrete: "+df.format(sv)+" m³\n"
                +"Beam concrete: "+df.format(bv)+" m³\n"
                +"Column concrete: "+df.format(cv)+" m³\n"
                +"Footing concrete: "+df.format(fv)+" m³\n"
                +"TOTAL concrete: "+df.format(total)+" m³\n"
                +"Planning steel allowance: "+df.format(steel)+" kg");
        });
        note("This building summary covers only the entered slab, beam, column and footing geometry. It excludes stairs, walls, lintels, openings, foundations beyond entered footings, deductions, wastage, laps, anchorage and construction tolerances. Enter steel intensities only when supplied by the project's qualified structural engineer. Not a structural design or bill of quantities.");
    }

    private void concrete() {
        setup("Concrete Calculator"); backButton(); heading("Rectangular concrete member");
        EditText l=input("Length (m)","5"), w=input("Width (m)","3"), d=input("Depth / thickness (m)","0.15");
        button("Calculate volume", () -> {
            double length=val(l), width=val(w), depth=val(d);
            if (!validPositive(length,width,depth)) { result("Enter valid positive dimensions in metres."); return; }
            result("Wet concrete volume: " + df.format(length*width*depth) + " m³");
        });
        note("Formula: Length × Width × Depth. Enter all dimensions in metres.");
    }
    private void steel() {
        setup("Steel Weight"); backButton(); heading("Reinforcement bar weight");
        EditText dia=input("Bar diameter (mm)","12"), len=input("Total bar length (m)","100");
        button("Calculate steel weight", () -> {
            double d=val(dia), length=val(len);
            if (!validPositive(d,length)) { result("Enter a valid positive bar diameter and total length."); return; }
            double weight = d*d/162.0*length;
            result("Approximate steel weight: " + df.format(weight) + " kg");
        });
        note("Formula: D² / 162 × length. This is a nominal unit-weight estimate; actual mass varies by standard and tolerance.");
    }
    private void brick() {
        setup("Brickwork"); backButton(); heading("Wall quantity");
        EditText l=input("Wall length (m)","4"), h=input("Wall height (m)","3"), t=input("Wall thickness (m)","0.20");
        EditText bl=input("Brick length incl. joint (m)","0.20"), bh=input("Brick height incl. joint (m)","0.10"), bt=input("Brick width incl. joint (m)","0.10");
        button("Calculate", () -> {
            double length=val(l), height=val(h), thickness=val(t), brickLength=val(bl), brickHeight=val(bh), brickThickness=val(bt);
            if(!validPositive(length,height,thickness,brickLength,brickHeight,brickThickness)) { result("Enter valid positive wall and brick dimensions."); return; }
            double wall=length*height*thickness, brickVol=brickLength*brickHeight*brickThickness;
            result("Wall volume: "+df.format(wall)+" m³\nApprox. brick count: "+df.format(wall/brickVol)+" bricks");
        });
        note("Uses wall volume divided by brick volume. Openings, breakage and bond details are not deducted or added.");
    }
    private void plaster() {
        setup("Plaster Calculator"); backButton(); heading("Plaster area and wet volume");
        EditText l=input("Wall length (m)","4"), h=input("Wall height (m)","3"), thick=input("Plaster thickness (mm)","12");
        button("Calculate", () -> {
            double length=val(l), height=val(h), thickness=val(thick);
            if(!validPositive(length,height,thickness)) { result("Enter positive wall dimensions and plaster thickness."); return; }
            result("Plaster area: "+df.format(length*height)+" m²\nApprox. wet mortar volume: "+df.format(length*height*thickness/1000.0)+" m³");
        });
        note("Single-side wall area. Deduct openings separately. Material quantities depend on specified mortar mix and wastage.");
    }
    private void tiles() {
        setup("Tile Calculator"); backButton(); heading("Floor tile quantity");
        EditText l=input("Floor length (m)","5"), w=input("Floor width (m)","4"), tl=input("Tile length (m)","0.6"), tw=input("Tile width (m)","0.6"), waste=input("Wastage (%)","5");
        button("Calculate", () -> {
            double length=val(l), width=val(w), tileLength=val(tl), tileWidth=val(tw), wastePct=val(waste);
            if(!validPositive(length,width,tileLength,tileWidth) || !validNonNegative(wastePct) || wastePct>100) { result("Enter positive floor/tile dimensions and wastage from 0 to 100%."); return; }
            double area=length*width, tileArea=tileLength*tileWidth;
            result("Floor area: "+df.format(area)+" m²\nTiles required incl. wastage: "+df.format(Math.ceil(area/tileArea*(1+wastePct/100)))+" tiles");
        });
        note("Allows a wastage percentage. Layout, cuts and pattern may change the actual requirement.");
    }
    private void cost() {
        setup("Construction Cost"); backButton(); heading("Basic area-based estimate");
        EditText area=input("Built-up area (sq.ft)","1200"), rate=input("Rate per sq.ft (₹)","2000");
        button("Estimate cost", () -> {
            double a=val(area), r=val(rate);
            if(!validPositive(a,r)) { result("Enter a positive built-up area and rate."); return; }
            result("Estimated construction cost: ₹ "+df.format(a*r));
        });
        note("This is a preliminary area × rate estimate, not a detailed bill of quantities or contractor quotation.");
    }
}
