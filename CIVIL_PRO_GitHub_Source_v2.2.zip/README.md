# CIVIL PRO — Android source project (v2.2)

## This package
- Complete Android Studio / Gradle source project.
- All 15 supplied Excel workbooks preserved under `docs/reference_workbooks/`.
- Extracted workbook formula register at `docs/EXTRACTED_EXCEL_FORMULAS.md`.
- Fifteen offline workbook-based calculator screens.
- User-provided ARULJOTHI logo installed in the app home screen and launcher icon.
- GitHub Actions workflow at `.github/workflows/android.yml` builds a debug APK.

## Workbook calculator mapping
1. Concrete slab, 2. concrete beam, 3. concrete column, 4. concrete footing,
5. steel slab, 6. steel beam, 7. steel column, 8. steel footing,
9. brickwork, 10. material quantity, 11. plastering, 12. painting,
13. plaster + painting, 14. tile quantity, 15. total building cost.

The app uses the equations and factors found in the supplied workbooks. Where a workbook has multiple rows, the screen is a practical single-entry calculator using the row formula; the formula register preserves the cell formulas for reference. Some source sheets have inconsistent or questionable formulas (notably footing bar count) and fixed sample rates. These have not been silently corrected. Verify results and current rates before estimating or purchasing.

## Build on GitHub using a phone
1. Extract this ZIP on your phone.
2. Upload the **contents inside** this ZIP to the root of your existing `CIVIL-PRO` GitHub repository (the folder containing `settings.gradle`).
3. Commit the changes to the main branch.
4. Open the repository's **Actions** tab and select the latest **Android CI** run.
5. When it finishes successfully, open the run and download the `CIVIL-PRO-debug-apk` artifact.
6. Extract the downloaded artifact ZIP and install `app-debug.apk`.

If GitHub shows an error, share a screenshot of the failed Actions log.

## Important
- This workflow creates a **debug APK for testing**, not a Play Store signed release.
- Calculations are offline; internet is only needed to download/install or update the app.
- Reinforcement quantity is not structural design. The workbook factors and outputs must be checked against approved drawings and applicable Indian Standards by a qualified engineer.
- Confirm dimensions, unit conventions, concrete mix assumptions, wastage and live material/labour rates before using outputs in a quotation or procurement.
