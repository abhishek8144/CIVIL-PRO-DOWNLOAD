CIVIL PRO v2.2 package update

This ZIP contains a complete Gradle Android project at its root. Upload its contents to the root of the CIVIL-PRO repository. GitHub Actions builds a debug APK using .github/workflows/android.yml. The launcher icon and home-screen brand image use the exact ARULJOTHI logo uploaded by the user.
